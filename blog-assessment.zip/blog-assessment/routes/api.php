<?php

use App\Http\Controllers\ArticleController;

Route::apiResource('articles', ArticleController::class);
